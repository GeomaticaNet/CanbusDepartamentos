# language-switcher
implementing a drop-down menu for language switching with CSS and HTML only


- Auther : Fadi Nouh
- URL : https://bluebits.dev
- Repository: https://github.com/bluebits-academy/language-switcher



![](https://bluebits.dev/wp-content/uploads/2020/06/F82C8F13-A6F1-4F4C-8B2A-7BF73AEEE75F.gif)
